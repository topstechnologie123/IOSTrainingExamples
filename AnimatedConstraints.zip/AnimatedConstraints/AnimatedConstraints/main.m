//
//  main.m
//  AnimatedConstraints
//
//  Created by Keith Harrison on 17/05/2015.
//  Copyright (c) 2015 Keith Harrison. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
