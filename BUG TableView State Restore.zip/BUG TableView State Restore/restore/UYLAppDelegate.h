//
//  UYLAppDelegate.h
//  restore
//
//  Created by Keith Harrison on 17/03/2013.
//  Copyright (c) 2013 Keith Harrison. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UYLAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
