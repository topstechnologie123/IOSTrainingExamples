### Static Table View Support for Dynamic Type

A look at how to get dynamic type working with static table views. See the following post further details:

+ [Static Tables and Dynamic Type](http://useyourloaf.com/blog/static-tables-and-dynamic-type/)

#### Version History

+ Version 1.0  25 Apr 2016    Initial Version