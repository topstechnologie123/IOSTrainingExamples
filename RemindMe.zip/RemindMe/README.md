### RemindMe

Version 1.2 01 Jul 2016 Update to Xcode 8 and iOS 10     
Version 1.1 06 Sep 2012 Minor updates to remove iOS 3 support
Version 1.0 31 Jul 2010 Initial release

The RemindMe App is a demonstration on how to schedule local notifications using UILocalNotification.

The original posts were written for iOS 4 a long time ago:

+ [Repeating an iOS local notification](http://useyourloaf.com/blog/repeating-an-ios-local-notification/)
+ [Add Local Notification with iOS 4](http://useyourloaf.com/blog/adding-local-notifications-with-ios-4/)
